/* Taskora - small interactions (no libraries needed) */
(() => {
  'use strict';

  /* 1. Mobile menu: close after a link is clicked, or on Escape */
  const menuToggle = document.getElementById('menu-toggle');
  document.querySelectorAll('.nav a').forEach((link) => {
    link.addEventListener('click', () => { if (menuToggle) menuToggle.checked = false; });
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && menuToggle) menuToggle.checked = false;
  });

  /* 2. FAQ: keep only one answer open at a time */
  const faqs = document.querySelectorAll('.faq');
  faqs.forEach((item) => {
    item.addEventListener('toggle', () => {
      if (!item.open) return;
      faqs.forEach((other) => { if (other !== item) other.open = false; });
    });
  });

  /* 3. Sign up: password and confirm password must match */
  const password = document.getElementById('signup-password');
  const confirm = document.getElementById('signup-confirm');
  if (password && confirm) {
    const check = () => {
      confirm.setCustomValidity(
        confirm.value && confirm.value !== password.value ? 'Passwords do not match' : ''
      );
    };
    password.addEventListener('input', check);
    confirm.addEventListener('input', check);
  }

  /* 4. Forms: demo behaviour - show a message, nothing is sent anywhere.
        Replace this with a real endpoint (for example Formspree) when you go live. */
  document.querySelectorAll('form[data-demo]').forEach((form) => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const status = form.querySelector('.form__status');
      if (status) status.textContent = form.dataset.success;
      form.reset();
    });
  });

  /* 5. Footer year */
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();
})();
